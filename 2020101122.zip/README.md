# BMSID

## Name: Siddharth Mavani
## Roll Number: 2020101122

### Instructions for Running the Code

- The code is written in C++ 11
- The code can be compiled using the following command:
```
g++ -std=c++11 main.cpp
```
- The code can be run using the following command:
```
./a.out
```
